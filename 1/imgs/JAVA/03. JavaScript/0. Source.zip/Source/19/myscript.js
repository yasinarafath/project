var i = 50;

while ( i >= 10) {
	document.write( i, "<br>");
	i--;
}