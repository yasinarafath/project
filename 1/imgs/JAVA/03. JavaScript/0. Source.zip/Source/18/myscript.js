var i;
for ( i = 1; i<=100; i++ ){
	if(i%2 == 1){
		document.write(i, "<br>");
	}
}
