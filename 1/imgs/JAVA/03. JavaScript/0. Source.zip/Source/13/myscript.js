var a = 5;
var b = 62;
var c = b%a;

console.log(c);