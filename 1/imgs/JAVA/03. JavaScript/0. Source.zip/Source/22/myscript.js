var age = 10;

age >= 18 ? document.write("YES, You can Vote!") : document.write("No, You can not Vote.")