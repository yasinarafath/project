	var a = 5;
	var b = 6;	

function testFunction(){

	document.write(a*b);
}
testFunction();

document.write("<br>", a+b);