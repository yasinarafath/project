var taka = 50;
var coupon = 1;

if ( taka >= 100 ){
	console.log('YES! You can buy a car.');
}else if ( coupon = 1 ){
	console.log('YES! You can buy a car with your coupon code.');
}else{
	console.log('No! You can not buy a car.');
}

