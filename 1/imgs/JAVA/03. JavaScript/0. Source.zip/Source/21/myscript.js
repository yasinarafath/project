var country = ["Bangladesh", "India", 30,"Pakistan", "USA",50 ]

country[6] = "Canada";

document.getElementById("demo").innerHTML = country[6];