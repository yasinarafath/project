var a = 5;
var b = 6;
var c = a+b;

console.log(c);


var firstName = "Abdul";
var lastName = "Kader";
var age = 22;

console.log(firstName, " " ,lastName, " is ", age, "years old.");