var i = 50;

do {
	document.write( i, "<br>");
	i--;
}while ( i >= 10 );