var car = { name:"Lamborghini", color:"white", model:"Aventador" }

document.getElementById("demo").innerHTML = car.color;