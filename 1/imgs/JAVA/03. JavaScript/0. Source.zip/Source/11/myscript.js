var pocket;
pocket = 50;

console.log(pocket);

var firstName;
firstName = "Abdul";

console.log(firstName);

var fruit = "Mango";
console.log(fruit);


