function weightConverter(numValue){
	document.getElementById("outputKg").innerHTML = numValue/2.204;
}